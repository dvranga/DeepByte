import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss'],
})
export class UserComponent implements OnInit {
  showJson: boolean = false;
  userForm: any = {};
  currentAge: any = '';
  showCurrentAge: boolean = false;

  onDateChange(date: any) {
    if (date) {
      this.showCurrentAge = true;
      var birthDate = new Date(date);
      var difference = Date.now() - birthDate.getTime();
      var ageDate = new Date(difference);
      var calculatedAge = Math.abs(ageDate.getUTCFullYear() - 1970);
      this.currentAge = calculatedAge;
    }
  }

  onSubmit(event: any) {}

  formSubmitted = false;

  constructor() {}

  ngOnInit() {}

  addUser(form: any) {
    this.formSubmitted = true;
  }

  onReset(form: any) {
    this.formSubmitted = false;
    this.showCurrentAge = false;
    form.reset();
  }

  onAction(form: any, action: any) {
    if (action == 'reset') {
      if (this.formSubmitted) {
        window.alert('Clear The Form?');
      }
      this.showJson = false;
      this.formSubmitted = false;
      this.showCurrentAge = false;
      form.reset();
    } else {
      this.formSubmitted = true;
      if (form.valid) {
        let date = form.value.date;
        let output = date.split('-');
        let newDate = [output[2], output[1], output[0]].join('/');
        this.userForm = form.value;
        Object.assign(this.userForm, { date: newDate });
        this.showJson = true;
      }
    }
  }
}

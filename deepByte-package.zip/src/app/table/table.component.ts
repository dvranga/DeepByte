import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss'],
})
export class TableComponent implements OnInit {
  tableData: any = [];
  eachdataObj: any = {};

  batterArr: any = [];

  constructor() {}

  ngOnInit() {
    this.displayTable();
  }

  displayTable() {
    for (let dataObj of this.data) {
      var globalObj: any = {
        id: '',
        type: '',
        name: '',
        ppu: '',
        batters: '',
        topping: '',
      };
      this.eachdataObj = dataObj;
      for (let value in dataObj) {
        if (value != 'batters' && value != 'topping') {
          globalObj[value] = this.eachdataObj[value];
        }
        if (value == 'topping') {
          globalObj[value] = this.eachdataObj[value]
            .map((ele: any) => ele.type)
            .join(', ');
        }
        if (value == 'batters') {
          this.batterArr = this.eachdataObj[value].batter.map(
            (ele: any) => ele.type
          );
          for (let batter of this.batterArr) {
            globalObj[value] = batter;
            this.tableData.push(globalObj);
            console.log(globalObj);
          }
        }
      }
    }
  }

  data = [
    {
      id: '0001',
      type: 'donut',
      name: 'Cake',
      ppu: 0.55,
      batters: {
        batter: [
          { id: '1001', type: 'Regular' },
          { id: '1002', type: 'Chocolate' },
          { id: '1003', type: 'Blueberry' },
        ],
      },
      topping: [
        { id: '5001', type: 'None' },
        { id: '5002', type: 'Glazed' },
        { id: '5005', type: 'Sugar' },
        { id: '5007', type: 'Powdered Sugar' },
      ],
    },
    {
      id: '0002',
      type: 'donut',
      name: 'Cake',
      ppu: 0.55,
      batters: {
        batter: [{ id: '1001', type: 'Regular' }],
      },
      topping: [
        { id: '5001', type: 'None' },
        { id: '5002', type: 'Glazed' },
      ],
    },
    {
      id: '0003',
      type: 'donut',
      name: 'Cake',
      ppu: 0.55,
      batters: {
        batter: [{ id: '1001', type: 'Regular' }],
      },
      topping: [
        { id: '5001', type: 'None' },
        { id: '5002', type: 'Glazed' },
      ],
    },
  ];
}

import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  ViewChild,
} from '@angular/core';
import { UserComponent } from './../user/user.component';

@Component({
  selector: 'app-action',
  templateUrl: './action.component.html',
  styleUrls: ['./action.component.scss'],
})
export class ActionComponent implements OnInit {
  @Output() action = new EventEmitter();

  constructor() {}

  ngOnInit(): void {}

  onRefresh() {
    this.action.emit('reset');
  }

  onSubmit() {
    this.action.emit('submit');
  }
}
